# Contact-Form-PHP
Working Contact Form in PHP. Please note you need to implement changes in contact.php ie place your email address and password.

This contact form has basic security features which you can choose to extend upon.

Built using tutorials, and  other resources.
Thanks
